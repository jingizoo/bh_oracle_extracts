/* ============================================================================
   Workday EIB � Supplier Invoice Adjustment LINES (Invoice Line Replacement Data)
   Update for slide criteria:
   - ONLY adjustment vouchers in last 12 months
   - ONLY open/not-cancelled vouchers
   - Lines driven from PS_VOUCHER_LINE for those vouchers
   ============================================================================
   Criteria:
     v.voucher_style = 'ADJ'
     v.entry_status <> 'X'
     v.close_status <> 'C'
     TRUNC(NVL(v.invoice_dt, v.entered_dt)) between lookback_dt and asof_dt
   ============================================================================ */

WITH
params AS (
  SELECT TRUNC(to_date('01-01-2026','DD-MM-YYYY')) AS asof_dt,
         ADD_MONTHS(TRUNC(To_date('01-01-2026','DD-MM-YYYY')), -12) AS lookback_dt
  FROM dual
),

/*Voucher List*/
vchr_list as (
select distinct v.*
FROM ps_voucher v
JOIN params p
  ON 1=1
JOIN ps_bh_wd_sup_1to1 wd
  ON v.vendor_id = wd.bh_wd_ps_vendor_id
JOIN ps_voucher_line vl
  ON vl.business_unit = v.business_unit
 AND vl.voucher_id    = v.voucher_id
WHERE v.gross_amt < 0 and v.voucher_style<>'JRNL' and v.origin <> 'FAV'
   AND v.appr_status = 'A'
  AND v.entry_status <> 'X'
  AND v.close_status <> 'C'
  AND TRUNC(NVL(v.invoice_dt, v.entered_dt)) BETWEEN p.lookback_dt AND p.asof_dt
 AND vl.merchandise_amt <>0
),



/* Paid zero amount vouchers (restricted to candidates; avoids full scan of xref) */
paid_zero_amt_xref AS  (
    SELECT /*+ MATERIALIZE */
           px.business_unit,
           px.voucher_id
    FROM ps_pymnt_vchr_xref px
    JOIN vchr_list vc
      ON vc.business_unit = px.business_unit
     AND vc.voucher_id   = px.voucher_id
    WHERE px.pymnt_action <> 'X'
    GROUP BY px.business_unit, px.voucher_id
    HAVING
        SUM(CASE WHEN px.pymnt_selct_status <> 'P' THEN 1 ELSE 0 END) = 0
    AND SUM(CASE WHEN px.paid_amt < 0 THEN 1 ELSE 0 END) > 0

),

/* AT THIS POINT WE EXCLUDE THE PAID VOUCHERS*/

vchr_base AS (
  SELECT pv.*
  FROM vchr_list pv
  WHERE NOT EXISTS (
      SELECT 1 FROM paid_zero_amt_xref px1
      WHERE px1.business_unit = pv.business_unit
        AND px1.voucher_id    = pv.voucher_id
    )
),

/*calculate the partial paid vocuher amount */
paid_amt_sum AS (
    SELECT
           px.business_unit,
           px.voucher_id,
           abs(SUM(px.paid_amt)) AS total_paid_amt
    FROM ps_pymnt_vchr_xref px
   JOIN vchr_base vc
    ON vc.business_unit = px.business_unit
   AND vc.voucher_id    = px.voucher_id
  WHERE px.pymnt_action <> 'X'
    AND px.paid_amt< 0 and pymnt_selct_status='P'
    GROUP BY px.business_unit, px.voucher_id
),


/*Aggregate the amount on lines and pick the line number of -ve amount*/
net_adj_lines AS (
    SELECT
        vl.business_unit,
        vl.voucher_id,

        /* Pick the negative line (the one to keep in Workday) */
        MAX(CASE 
              WHEN vl.merchandise_amt < 0 
              THEN vl.voucher_line_num 
            END) AS neg_line_num,

        /* Net of all lines */
        SUM(vl.merchandise_amt) AS net_merch_amt1,
/*calculate remaining amount*/
       abs(SUM(vl.merchandise_amt)) - max(nvl(pa.total_paid_amt,0)) AS net_merch_amt
    FROM ps_voucher_line vl
    JOIN vchr_base vb
      ON vb.business_unit = vl.business_unit
     AND vb.voucher_id    = vl.voucher_id
    left join paid_amt_sum pa
    ON vb.business_unit = pa.business_unit
     AND vb.voucher_id    = pa.voucher_id
    WHERE vl.merchandise_amt <> 0
    GROUP BY
        vl.business_unit,
        vl.voucher_id

    HAVING SUM(vl.merchandise_amt) <> 0
),


/* Optional: PO list if you later decide to populate PO-related columns */
po_list AS (
  SELECT
      vl.business_unit,
      vl.voucher_id,
      LISTAGG(TRIM(vl.po_id), ';' ON OVERFLOW TRUNCATE '...' WITHOUT COUNT)
        WITHIN GROUP (ORDER BY TRIM(vl.po_id)) AS external_po_number
  FROM ps_voucher_line vl
  WHERE EXISTS (
    SELECT 1
    FROM vchr_base vb
    WHERE vb.business_unit = vl.business_unit
      AND vb.voucher_id    = vl.voucher_id
  )
    AND TRIM(vl.po_id) IS NOT NULL
    AND TRIM(vl.po_id) <> ''
  GROUP BY vl.business_unit, vl.voucher_id
),
dl_pick AS (
  SELECT business_unit, voucher_id, voucher_line_num, operating_unit, business_unit_gl
  FROM (
    SELECT
      d.business_unit,
      d.voucher_id,
      d.voucher_line_num,
      d.operating_unit,
      d.business_unit_gl,
      ROW_NUMBER() OVER (
        PARTITION BY d.business_unit, d.voucher_id, d.voucher_line_num
        ORDER BY CASE WHEN d.business_unit_gl = vh.business_unit_gl THEN 0 ELSE 1 END,
                 ABS(d.foreign_amount) DESC,
                 d.distrib_line_num
      ) AS rn
    FROM ps_distrib_line d
    JOIN ps_voucher vh
      ON vh.business_unit = d.business_unit
     AND vh.voucher_id    = d.voucher_id
    JOIN ps_voucher_line k
      ON k.business_unit     = d.business_unit
     AND k.voucher_id        = d.voucher_id
     AND k.voucher_line_num  = d.voucher_line_num
    
  )
  WHERE rn = 1
)

SELECT
    /* Keys */
    v.voucher_id                                      AS "*No.",
    v.voucher_id ||'-'||vl.neg_line_num                               AS "*Invoice Line Replacement Data Line No",
    ' '						      AS "Supplier Invoice Line ID",
    vl.neg_line_num                                   AS "Line Order",

    /* Required (per your template) � keep as your xwalk placeholder */
   x.bhxlat                                           AS "*Intercompany Affiliate",

    /* Line attributes */
    ' '                                               AS "Purchase Item",
    /* You can populate this with NVL(vl.descr254_mixed, vl.descr) if desired */
    ' '                                               AS "Item Description",
    ' '                                               AS "Purchase Order Line",
    ' '                                               AS "Supplier Contract Line",
    ' '                                               AS "Customer Invoice Line",
    ' '                                               AS "Supplier Invoice Line to Adjust",

    /* Required Spend Category (per your prior file) */
    'Conversion'                                      AS "*Spend Category",

    ' '                                               AS "Commodity Code",
    ' '                                               AS "Ship To Address",
    ' '                                               AS "Ship To Contact Is Employee",
    ' '                                               AS "Ship To Contact Worker ID",
    ' '                                               AS "Accounting Treatment",
    ' '                                               AS "Trackable Item",

    ' '                                               AS "Tax Applicability",
    ' '                                               AS "Tax Code",
    ' '                                               AS "Withholding Tax Code",
    ' '                                               AS "Tax Point Date Type",
    ' '                                               AS "Tax Point Date",
    ' '                                               AS "Tax Rate 1",
    ' '                                               AS "Tax Recoverability 1",
    ' '                                               AS "Tax Option 1",
    ' '                                               AS "Tax Recoverability 2",
    ' '                                               AS "Tax Option 2",
    ' '                                               AS "Tax Recoverability 3",
    ' '                                               AS "Tax Option 3",
    ' '                                               AS "Tax Recoverability 4",
    ' '                                               AS "Tax Option 4",
    ' '                                               AS "Tax Recoverability 5",
    ' '                                               AS "Tax Option 5",
    ' '                                               AS "Tax Recoverability 6",
    ' '                                               AS "Tax Option 6",

    ' '                                               AS "Packaging String",

    /* Quantities/pricing not used for these adjustments in your template */
    ' '                                               AS "Quantity",
    ' '                                               AS "Unit of Measure",
    ' '                                               AS "Unit Cost",

    /* Amount � keep signed amount as stored on the voucher line */
    abs(vl.net_merch_amt)                                AS "Extended Amount",

    ' '                                               AS "Retention Amount",
    ' '                                               AS "Payment Amount",
    ' '                                               AS "Budget Date",
    ' '                                               AS "Prepaid",
    ' '                                               AS "Supplier Contract",

    ' '                                               AS "Invoice Line Delivery Date",
    ' '                                               AS "Invoice Line Billing Start Date",
    ' '                                               AS "Invoice Line Billing End Date",

    /* Memo � keep blank per prior file; can also use line description */
    ' '                                               AS "Memo",

    ' '                                               AS "Billable",
    ' '                                               AS "Worktag Split Template"

FROM vchr_base vb
JOIN ps_voucher v
  ON v.business_unit = vb.business_unit
 AND v.voucher_id    = vb.voucher_id
JOIN net_adj_lines vl
  ON vl.business_unit = v.business_unit
 AND vl.voucher_id    = v.voucher_id
LEFT JOIN po_list pl
  ON pl.business_unit = v.business_unit
 AND pl.voucher_id    = v.voucher_id
LEFT JOIN dl_pick dl
 ON vl.business_unit = dl.business_unit
 AND vl.voucher_id    = dl.voucher_id
 and vl.neg_line_num=  dl.voucher_line_num
left join PS_BHXLATITEM x on x.fieldname='BH_WD_FDM_OU_COMP' and x.bhvalue=dl.operating_unit
where  abs(vl.net_merch_amt)<>0

ORDER BY v.voucher_id, vl.neg_line_num

